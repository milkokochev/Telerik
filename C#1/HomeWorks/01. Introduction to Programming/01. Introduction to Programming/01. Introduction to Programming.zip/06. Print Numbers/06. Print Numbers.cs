﻿using System;

class PrintNumbers
{
    static void Main()
    {
        Console.WriteLine("1 \n101 \n1001");
    }
}