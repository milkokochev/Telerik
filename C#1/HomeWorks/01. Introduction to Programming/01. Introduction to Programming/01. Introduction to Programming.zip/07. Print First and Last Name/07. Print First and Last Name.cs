﻿using System;

class FirstLastName
{
    static void Main()
    {
        Console.WriteLine("First Name");
        Console.WriteLine("Last Name");
    }
}