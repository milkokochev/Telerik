﻿using System;

    class Program
    {
        static void Main()
        {
            string firstName;
            string middleName;
            string lastName;
            decimal balance;
            string bankName;
            string iban;
            long firstCardNumber;
            long secondCardNumber;
            long thirdCardNumber;
        }
    }