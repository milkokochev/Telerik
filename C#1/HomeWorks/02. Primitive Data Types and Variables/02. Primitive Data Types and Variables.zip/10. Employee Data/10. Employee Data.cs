﻿using System;

class Program
{
    static void Main()
    {
        string firstName = "First Name";
        string familyName = "Family Name";
        byte age = 100;
        char gender = 'm';
        long idNumber = 9999999999;
        int employeeNumber = 27569999;

        Console.WriteLine("First name:" + firstName);
        Console.WriteLine("Family name:" + familyName);
        Console.WriteLine("age:" + age);
        Console.WriteLine("gender:" + gender);
        Console.WriteLine("ID:" + idNumber);
        Console.WriteLine("Employee number:" + employeeNumber);

    }
}