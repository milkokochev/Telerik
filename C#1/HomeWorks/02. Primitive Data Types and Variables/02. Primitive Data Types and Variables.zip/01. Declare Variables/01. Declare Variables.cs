﻿using System;

class Declare
{
    static void Main()
    {
        ushort firstnum = 52130;
        sbyte secondNum = -115;
        int thirdNum = 4825932;
        byte forthNum = 97;
        short fiftNum = -10000;

        Console.WriteLine("ushort --> " + firstnum);
        Console.WriteLine("sbyte --> " + secondNum);
        Console.WriteLine("int --> " + thirdNum);
        Console.WriteLine("byte --> " + forthNum);
        Console.WriteLine("short --> " + fiftNum);
    }
}