﻿using System;

    class FloatOrDouble
{
    static void Main()
    {
        double firstNum = 34.567839023;
        float secondNum = 12.345f;
        double thirdNum = 8923.1234857;
        float fourthNum = 3456.091f;

        Console.WriteLine("Float type numbers are: \n" + secondNum + "\n" + fourthNum);
        Console.WriteLine();
        Console.WriteLine("Double type numbers are: \n" + firstNum + "\n" + thirdNum);
    }
}
