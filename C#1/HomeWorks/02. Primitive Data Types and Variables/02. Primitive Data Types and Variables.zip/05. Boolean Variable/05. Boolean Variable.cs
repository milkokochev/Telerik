﻿using System;

    class Program
    {
        static void Main()
        {
            bool isFimale = false;
            Console.WriteLine("isFimale = " + isFimale);
        }
    }