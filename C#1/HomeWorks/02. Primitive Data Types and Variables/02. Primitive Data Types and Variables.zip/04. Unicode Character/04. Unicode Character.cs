﻿using System;

    class Unicode
    {
        static void Main()
        {
            char symbol = '\u002A';
            Console.WriteLine(symbol);
        }
    }