﻿using System;
class Program
{
    static void Main()
    {
        int hex = 0xFE;
        Console.WriteLine("0xFE = " + hex);
    }
}